CREATE TABLE StagingEmployee (
    [EmployeeID] float,
    [NationalIDNumber] nvarchar(max),
    [ContactID] float,
    [LoginID] nvarchar(max),
    [ManagerID] float,
    [Title] nvarchar(max),
    [BirthDate] datetime,
    [MaritalStatus] nvarchar(max),
    [Gender] nvarchar(max),
    [HireDate] datetime,
    [SalariedFlag] float,
    [VacationHours] float,
    [SickLeaveHours] float,
    [CurrentFlag] float,
    [rowguid] nvarchar(255),
    [ModifiedDate] datetime
)
